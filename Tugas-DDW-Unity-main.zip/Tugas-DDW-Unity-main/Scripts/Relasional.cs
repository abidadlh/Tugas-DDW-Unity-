using System.Collections;
using UnityEngine;

public class Operator : MonoBehaviour
{
    void Start()
    {
        int A = 2;
        int B = 3;

        Debug.Log(A > B);
    }
}