using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dua : MonoBehaviour
{

    void Start(){
        int umur = Satu.var;
        Debug.Log(umur);
        
    }

    void Update(){
        
    }
}