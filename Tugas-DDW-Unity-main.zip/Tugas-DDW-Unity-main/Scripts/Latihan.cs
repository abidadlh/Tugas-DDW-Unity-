using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Latihan : MonoBehaviour{
    // Start is called before the first frame update
    void Start(){
        Debug.Log("Saya sedang belajar C# Unity");
    }
   
    // Update is called once per frame
    void Update()
    {
        
    }
}
