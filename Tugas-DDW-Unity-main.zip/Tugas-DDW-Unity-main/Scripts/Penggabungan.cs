using System.Collections;
using UnityEngine;

public class Penggabungan : MonoBehaviour
{
    void Start()
    {
        int A = 3;
        Debug.Log("Nilai A adalah = " + A);
    }
}