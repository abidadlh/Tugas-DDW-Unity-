using System.Collections;
using UnityEngine;

public class Persamaan : MonoBehaviour
{
     void Start()
    {
        int A = 3;
        int B = 3;
        if(A == B)
            Debug.Log("A memiliki nilai yag sama dengan B");
    }
}