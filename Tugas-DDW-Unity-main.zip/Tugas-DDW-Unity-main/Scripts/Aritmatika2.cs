using System.Collections;
using UnityEngine;

public class Aritmatika2 : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        int A = 3 * 5;
        Debug.Log(A);
    }
}