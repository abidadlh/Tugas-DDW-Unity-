using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Satu : MonoBehaviour{

    public static int var = 9;
    void Start(){

    }

    void Update(){
        
    }
}